# Synthetic titlebar-drag reproducer

Tested source: Harness v0.2.163, commit 6d98cf481cb9ff53253d4f3a37502e4a54833877.
Executed on macOS 26.4.1 arm64. Latest release at filing: v0.2.167; not rerun there.

Extract these files into a new directory INSIDE a Harness checkout containing tag v0.2.163. Use the repository's Rust/native build prerequisites. Each script exports that tag into a fresh subdirectory with its own Cargo target. Neither script modifies the caller's tracked files or installed app. No personal Harness data is read. First compilation can take several minutes and considerable disk space.

```bash
bash path/to/extracted/reproduce.sh
bash path/to/extracted/native-return-reproduce.sh
```

## Expected results

`reproduce.sh`:
- Seven characterization/counterfactual tests pass against release handlers.
- Two correct-behavior regressions fail against unchanged v0.2.163 (exit 101).
- Apply handler-candidate.patch ONLY to the exported snapshot.
- The same two regressions pass, followed by four candidate safety tests and six existing right-tab mouse regressions.

`native-return-reproduce.sh`:
- Renders real Shell titlebar handlers over a real Transcript with 60 synthetic replies.
- Adds test-only observability and instruments only TestWindow's native-move stub to return immediately; no AppKit invocation or OS input synthesis.
- Omits MouseUp, which Apple's SDK explicitly permits after performWindowDragWithEvent:.
- Baseline correct-behavior regression fails with selection and auto-scroll active. Recorded offset: -396 to -453.01852 after 120 ms of deterministic timer advancement without more pointer input.
- Applies the same isolated candidate and reruns the same test: passes, selection/driver/timer inactive, offset -396 to -396.
- The script checks the baseline's specific failure text so a compilation/setup error is not treated as the expected regression.

The two shell scripts' steps were executed during investigation; the packaged fresh-directory wrappers were syntax-checked, not redundantly rebuilt end-to-end afterward.

## Important interpretation

The existing TestWindow::start_window_move panics with `not implemented`. Boundary-marker tests deliberately expect that panic to prove handoff was attempted. The first-upward-move regression FAILS on baseline because it never reaches that panic. This is not an application crash and does not prove physical native movement.

The lifecycle test replaces that stub with immediate return only when HARNESS_DIAGNOSTIC_NATIVE_RETURN is present. All selection, scroll scheduling and transcript rendering remain production code.

Candidate-only safety tests cover outside release, actual header button ownership, a button-origin drag entering the strip, and single/double-click dispatch. TestWindow's native double-click implementation is a no-op: actual zoom/minimize behavior is NOT verified.

The patch is a diagnostic fix direction, not a shipping fix. It does not retain the original native mouseDown event or cancel the macOS synthetic held-event replay. The physical absolute screen-height symptom remains unproven. No claim that these tests fail on current main is made: the baseline is the exact release named above.
