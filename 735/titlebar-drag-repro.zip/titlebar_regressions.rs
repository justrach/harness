//! Correct-behavior assertions: both intentionally fail on the unmodified
//! v0.2.163 production handlers. The diagnostic counterfactuals pass separately.
use super::*;

#[gpui::test]
#[should_panic(expected = "not implemented")]
fn titlebar_regression_first_upward_move_must_reach_native_boundary(cx: &mut TestAppContext) {
    let (_dir, _, cx) = setup(cx, false, false);
    press(cx, 400.0, 2.0);
    drag(cx, 400.0, -10.0);
    // Reaching GPUI's native-move test stub is the expected panic. On the
    // unchanged release this handler is never reached, so the test fails.
}

#[gpui::test]
fn titlebar_regression_header_press_must_not_start_transcript_selection(cx: &mut TestAppContext) {
    let _guard = crate::markdown::selection::test_state_lock();
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(TEXT_KEY);
    let (_dir, shell, cx) = setup(cx, true, false);
    let bounds = crate::markdown::render::selection_test_bounds(TEXT_KEY);
    let position = point(bounds.left() + px(12.0), bounds.top() + px(8.0));
    press(cx, position.x.into(), position.y.into());
    let window_armed = shell.read_with(cx, |shell, _| shell.titlebar_should_move);
    let selection_dragging = crate::markdown::selection::is_dragging();
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(TEXT_KEY);
    assert!(window_armed, "header press must retain window-drag ownership");
    assert!(!selection_dragging, "header-owned press also started transcript selection");
}
