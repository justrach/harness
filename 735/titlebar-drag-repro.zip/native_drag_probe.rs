//! Local test observability only; all selection/scroll work uses production code.
use super::*;

impl Transcript {
    pub(crate) fn native_drag_probe_sync(&mut self, cx: &mut Context<Self>) {
        self.sync(cx);
    }

    pub(crate) fn native_drag_probe_state(&self) -> (bool, bool, f32) {
        (
            self.selection_drag_position.is_some(),
            self.selection_scroll_task.is_some(),
            f32::from(self.list.scroll_px_offset_for_scrollbar().y),
        )
    }

    pub(crate) fn native_drag_probe_scroll(&mut self, delta: f32, cx: &mut Context<Self>) {
        self.begin_scroll_navigation();
        self.list.scroll_by(px(delta));
        cx.notify();
    }
}
