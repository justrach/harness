//! Model Apple's documented immediate native-handoff return without MouseUp.
//! Runs no AppKit and generates no OS input. The real Shell/Transcript handle
//! all GPUI events and scroll steps; only TestWindow's native boundary returns.
use super::*;

struct NativeReturnHost(Entity<Shell>);

impl Render for NativeReturnHost {
    fn render(&mut self, _: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        self.0.update(cx, |shell, cx| {
            let underlay = crate::edge_fade::edge_faded(
                24.0, true, false,
                div().size_full().child(shell.transcript.clone()),
            ).inset_top(Theme::TITLEBAR_HEIGHT);
            let header = shell.titlebar_drag_region(
                "native-return-titlebar",
                div().absolute().top_0().left_0().right_0().h(px(Theme::TITLEBAR_HEIGHT)),
                cx,
            );
            div().relative().size_full().child(underlay).child(header)
        })
    }
}

#[gpui::test]
fn titlebar_native_return_missing_mouse_up_must_not_leave_selection_scrolling(cx: &mut TestAppContext) {
    assert!(std::env::var_os("HARNESS_DIAGNOSTIC_NATIVE_RETURN").is_some(),
        "run only with the explicitly instrumented headless native-return stub");
    let _guard = crate::markdown::selection::test_state_lock();
    crate::markdown::selection::end_active_drag();
    let dir = tempfile::tempdir().unwrap();
    cx.update(|cx| {
        gpui_base::init(cx);
        cx.set_global(Theme::default());
        crate::app_menus::init(cx);
        settings::init(settings::UiSettings::default(), dir.path(), cx);
    });
    let (host, cx) = cx.add_window_view(|_, cx| NativeReturnHost(cx.new(|cx| {
        let state = cx.new(|_| {
            let mut state = AppState::new();
            state.selected_chat = Some("native-return-synthetic".into());
            state.transcript_replayed = true;
            state.transcript = (0..60).map(|i| harness_doc::SessionMessageEntry {
                id: format!("synthetic-reply-{i}"),
                role: harness_doc::MessageRole::Assistant,
                parts: vec![harness_doc::MessagePart::Text {
                    id: "text".into(),
                    text: format!("Synthetic response {i}: this paragraph exists only to exercise title-bar gesture ownership and scrolling."),
                }],
                created_at: i,
                device_id: "synthetic".into(),
                status: Some(harness_doc::MessageStatus::Complete),
                continuation_of: None,
                duration_ms: None,
            }).collect();
            state.transcript_revision += 1;
            state
        });
        Shell::new(state, EngineBootConfig {
            data_dir: dir.path().into(),
            ipc_port: 0,
            edge_url: "http://127.0.0.1:1".into(),
            edge_token: None,
            org_id: None,
            codegraff_client_id: None,
            default_harness: harness_proto::HarnessId::Mock,
        }, cx)
    })));
    cx.simulate_resize(size(px(900.0), px(500.0)));
    let shell = host.read_with(cx, |host, _| host.0.clone());
    let transcript = shell.read_with(cx, |shell, _| shell.transcript.clone());
    for _ in 0..3 {
        transcript.update(cx, |t, cx| t.native_drag_probe_sync(cx));
        cx.run_until_parked();
        cx.update(|window, cx| { window.refresh(); let _ = window.draw(cx); });
    }
    let under_header = |entry: &(String, String, gpui::Bounds<gpui::Pixels>)| {
        entry.1.starts_with("Synthetic response") && entry.2.top() < px(30.0) && entry.2.bottom() > px(4.0)
    };
    let mut entries = crate::markdown::render::selection_test_entries();
    for _ in 0..30 {
        if entries.iter().any(&under_header) { break; }
        cx.simulate_event(gpui::ScrollWheelEvent {
            position: point(px(400.0), px(250.0)),
            delta: gpui::ScrollDelta::Pixels(point(px(0.0), px(12.0))),
            ..Default::default()
        });
        cx.run_until_parked();
        cx.update(|window, cx| { window.refresh(); let _ = window.draw(cx); });
        entries = crate::markdown::render::selection_test_entries();
    }
    let (key, _, bounds) = entries.iter().find(|entry| under_header(entry)).unwrap_or_else(|| {
        panic!("no text under header; registered entries={}, sample={:?}", entries.len(), entries.iter().take(3).collect::<Vec<_>>())
    });
    let y = f32::from(bounds.top() + px(6.0)).max(6.0).min(28.0);
    let x = f32::from(bounds.left() + px(12.0));
    let start = point(px(x), px(y));
    assert!(bounds.contains(&start));
    let before = transcript.read_with(cx, |t, _| t.native_drag_probe_state());
    press(cx, x, y);
    assert!(shell.read_with(cx, |s, _| s.titlebar_should_move));
    drag(cx, x + 1.0, y - 1.0);
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move),
        "actual Shell native handoff must have run and returned");
    // No MouseUp is sent: Apple's API explicitly permits this outcome.
    let after_return = transcript.read_with(cx, |t, _| t.native_drag_probe_state());
    let selection_active = crate::markdown::selection::is_dragging();
    for _ in 0..5 {
        cx.executor().advance_clock(std::time::Duration::from_millis(24));
        cx.run_until_parked();
        cx.update(|window, cx| { window.refresh(); let _ = window.draw(cx); });
    }
    let after_steps = transcript.read_with(cx, |t, _| t.native_drag_probe_state());
    eprintln!("NATIVE_RETURN down=({x},{y}), move=({},{}), no MouseUp: selection_active={selection_active}, driver_after_return={}, timer_after_return={}, offset_before={}, offset_after_120ms={}",
        x + 1.0, y - 1.0, after_return.0, after_return.1, before.2, after_steps.2);
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(key);
    assert!(!selection_active && !after_return.0 && !after_return.1,
        "header-owned native drag left transcript selection and auto-scroll active after handoff");
    assert_eq!(before.2, after_steps.2, "transcript scrolled without another pointer event");
}
