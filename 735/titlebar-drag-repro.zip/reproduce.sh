#!/usr/bin/env bash
# Portable synthetic reproduction. Does not read Harness application data,
# change the installed app, or edit the caller's tracked source files.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
root="$(git -C "$here" rev-parse --show-toplevel)"
work="$(mktemp -d "$here/reproduction.XXXXXX")"
mkdir "$work/source"
git -C "$root" archive v0.2.163 | tar -x -C "$work/source"
cp "$here/titlebar_diagnostics.rs" "$work/source/crates/ui/src/shell/"
cp "$here/titlebar_regressions.rs" "$work/source/crates/ui/src/shell/"
cp "$here/titlebar_safety.rs" "$work/source/crates/ui/src/shell/"
python3 - "$work/source/crates/ui/src/shell/titlebar_tests.rs" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
source = path.read_text()
assert source.count('use super::*;\n') == 1
path.write_text(source.replace('use super::*;\n', 'use super::*;\n\n#[path = "titlebar_diagnostics.rs"]\nmod titlebar_diagnostics;\n', 1))
PY
export CARGO_TARGET_DIR="$work/target"
run_tests() {
    "$root/scripts/heavy-build.sh" cargo test \
        --manifest-path "$work/source/Cargo.toml" -p harness-ui --lib "$1" \
        -j 4 --config profile.dev.debug=0 --config profile.test.debug=0 \
        -- --nocapture --test-threads=1
}
# Seven characterization/counterfactual tests should pass. Expected panics
# are specifically the GPUI TestWindow native-move stub, not an app crash.
run_tests titlebar_diagnostics_
# Two correct-behaviour regressions should fail on the unchanged release.
set +e
run_tests titlebar_regression_
status=$?
set -e
printf '\nCorrect-behaviour regression exit status: %s (expected 101 on v0.2.163)\n' "$status"
printf 'Synthetic source and build artifacts retained at: %s\n' "$work"
if [[ "$status" != 101 ]]; then
    printf 'Unexpected regression outcome; inspect the test output.\n' >&2
    exit 1
fi
# Apply the candidate ONLY to the exported source. The same two regressions
# must now pass; this still does not execute AppKit's native window drag.
patch -d "$work/source" -p 1 < "$here/handler-candidate.patch"
run_tests titlebar_regression_
run_tests titlebar_safety_
run_tests right_tab_mouse_regressions
