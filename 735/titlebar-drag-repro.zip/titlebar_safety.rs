//! Candidate-only input-routing checks. These do not exercise native AppKit.
use super::*;

fn release(cx: &mut VisualTestContext, x: f32, y: f32, count: usize) {
    cx.simulate_event(MouseUpEvent {
        position: point(px(x), px(y)),
        button: MouseButton::Left,
        click_count: count,
        ..Default::default()
    });
}

#[gpui::test]
fn titlebar_safety_release_outside_disarms_and_hover_does_not_start_move(cx: &mut TestAppContext) {
    let (_dir, shell, cx) = setup(cx, false, false);
    press(cx, 400.0, 2.0);
    assert!(shell.read_with(cx, |s, _| s.titlebar_should_move));
    release(cx, 400.0, -10.0, 1);
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
    cx.simulate_event(MouseMoveEvent {
        position: point(px(400.0), px(8.0)),
        pressed_button: None,
        ..Default::default()
    });
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
}

#[gpui::test]
fn titlebar_safety_real_header_button_click_is_not_a_window_drag(cx: &mut TestAppContext) {
    let clicks = std::rc::Rc::new(std::cell::Cell::new(0));
    let (_dir, shell, cx) = setup_full(cx, false, false, false, false, Some(clicks.clone()), None);
    press(cx, 392.0, 16.0);
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
    drag(cx, 393.0, 17.0);
    release(cx, 393.0, 17.0, 1);
    assert_eq!(clicks.get(), 1);
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
}

#[gpui::test]
fn titlebar_safety_drag_from_button_to_blank_strip_does_not_move_window(cx: &mut TestAppContext) {
    let clicks = std::rc::Rc::new(std::cell::Cell::new(0));
    let (_dir, shell, cx) = setup_full(cx, false, false, false, false, Some(clicks.clone()), None);
    press(cx, 392.0, 16.0);
    drag(cx, 450.0, 16.0);
    assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
    release(cx, 450.0, 16.0, 1);
    assert_eq!(clicks.get(), 0);
}

#[gpui::test]
fn titlebar_safety_blank_strip_click_and_double_click_dispatch_are_preserved(cx: &mut TestAppContext) {
    let clicks = std::rc::Rc::new(std::cell::Cell::new(0));
    let (_dir, shell, cx) = setup_full(cx, false, false, false, false, None, Some(clicks.clone()));
    for count in [1, 2] {
        cx.simulate_event(MouseDownEvent {
            position: point(px(400.0), px(18.0)),
            button: MouseButton::Left,
            click_count: count,
            ..Default::default()
        });
        assert!(shell.read_with(cx, |s, _| s.titlebar_should_move));
        release(cx, 400.0, 18.0, count);
        assert!(!shell.read_with(cx, |s, _| s.titlebar_should_move));
        assert_eq!(clicks.get(), count);
    }
    // TestWindow's titlebar_double_click is a no-op: this establishes GPUI
    // dispatch only, not the native macOS zoom/minimize preference outcome.
}
