//! Local synthetic diagnostics against v0.2.163, not a proposed application patch.
use super::*;

#[path = "titlebar_regressions.rs"]
mod regressions;

#[path = "titlebar_safety.rs"]
mod safety;
use gpui::{MouseDownEvent, MouseMoveEvent, MouseUpEvent, TestAppContext, VisualTestContext, point, size};

const TEXT_KEY: &str = "titlebar-diagnostic-text";

struct DiagnosticHost {
    shell: Entity<Shell>,
    text_under_header: bool,
    occlude_header: bool,
    consume_header_press: bool,
    window_level_handoff: bool,
    button_clicks: Option<std::rc::Rc<std::cell::Cell<usize>>>,
    header_clicks: Option<std::rc::Rc<std::cell::Cell<usize>>>,
}

impl Render for DiagnosticHost {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let text = self.text_under_header.then(|| {
            crate::edge_fade::edge_faded(
                24.0,
                true,
                false,
                div().size_full().child(
                    div().absolute().left(px(180.0)).top(px(4.0)).w(px(500.0)).child(
                        crate::markdown::render::selectable_text_element(
                            std::sync::Arc::from(TEXT_KEY),
                            "Synthetic reply underneath the window header".into(),
                            vec![window.text_style().to_run("Synthetic reply underneath the window header".len())],
                            gpui::rgba(0x4488ff88).into(),
                        ),
                    ),
                ),
            )
            .inset_top(Theme::TITLEBAR_HEIGHT)
        });
        let header = self.shell.update(cx, |shell, cx| {
            let button = self.button_clicks.clone().map(|clicks| {
                header_icon_button(
                    "diagnostic-header-button",
                    icons::SIDEBAR_MINIMALISTIC,
                    &Theme::of(cx).clone(),
                    move |_, _, _| clicks.set(clicks.get() + 1),
                ).absolute().left(px(380.0)).top(px(4.0))
            });
            shell.titlebar_drag_region(
                "diagnostic-titlebar",
                div().absolute().top_0().left_0().right_0().h(px(Theme::TITLEBAR_HEIGHT)).children(button),
                cx,
            )
            .when_some(self.header_clicks.clone(), |header, clicks| {
                header.on_click(move |_, _, _| clicks.set(clicks.get() + 1))
            })
            .when(self.occlude_header, |header| header.occlude())
            .when(self.consume_header_press, |header| {
                header.on_mouse_down(MouseButton::Left, cx.listener(|shell, _, _, cx| {
                    shell.titlebar_should_move = true;
                    cx.stop_propagation();
                }))
            })
        });
        // A diagnostic counterfactual, not a change to the release helper:
        // continue the owned gesture at window scope rather than hover scope.
        let weak_shell = self.shell.downgrade();
        let handoff = self.window_level_handoff.then(|| {
            gpui::canvas(|_, _, _| (), move |_, _, window, _| {
                let weak_shell = weak_shell.clone();
                window.on_mouse_event(move |event: &MouseMoveEvent, phase, window, cx| {
                    if phase != gpui::DispatchPhase::Capture {
                        return;
                    }
                    let _ = weak_shell.update(cx, |shell, cx| {
                        if shell.titlebar_should_move && event.pressed_button == Some(MouseButton::Left) {
                            shell.titlebar_should_move = false;
                            cx.stop_propagation();
                            window.start_window_move();
                        }
                    });
                });
            }).absolute().size_0()
        });
        div().relative().size_full().children(text).child(header).children(handoff)
    }
}

fn setup(
    cx: &mut TestAppContext,
    text_under_header: bool,
    occlude_header: bool,
) -> (tempfile::TempDir, Entity<Shell>, &mut VisualTestContext) {
    setup_with_policy(cx, text_under_header, occlude_header, false, false)
}

fn setup_with_policy(
    cx: &mut TestAppContext,
    text_under_header: bool,
    occlude_header: bool,
    consume_header_press: bool,
    window_level_handoff: bool,
) -> (tempfile::TempDir, Entity<Shell>, &mut VisualTestContext) {
    setup_full(cx, text_under_header, occlude_header, consume_header_press, window_level_handoff, None, None)
}

fn setup_full(
    cx: &mut TestAppContext,
    text_under_header: bool,
    occlude_header: bool,
    consume_header_press: bool,
    window_level_handoff: bool,
    button_clicks: Option<std::rc::Rc<std::cell::Cell<usize>>>,
    header_clicks: Option<std::rc::Rc<std::cell::Cell<usize>>>,
) -> (tempfile::TempDir, Entity<Shell>, &mut VisualTestContext) {
    let dir = tempfile::tempdir().unwrap();
    cx.update(|cx| {
        gpui_base::init(cx);
        cx.set_global(Theme::default());
        crate::app_menus::init(cx);
        settings::init(settings::UiSettings::default(), dir.path(), cx);
    });
    let (host, cx) = cx.add_window_view(|_, cx| DiagnosticHost {
        shell: cx.new(|cx| {
            let state = cx.new(|_| AppState::new());
            Shell::new(
                state,
                EngineBootConfig {
                    data_dir: dir.path().into(),
                    ipc_port: 0,
                    edge_url: "http://127.0.0.1:1".into(),
                    edge_token: None,
                    org_id: None,
                    codegraff_client_id: None,
                    default_harness: harness_proto::HarnessId::Mock,
                },
                cx,
            )
        }),
        text_under_header,
        occlude_header,
        consume_header_press,
        window_level_handoff,
        button_clicks,
        header_clicks,
    });
    cx.simulate_resize(size(px(900.0), px(500.0)));
    cx.update(|window, cx| { window.refresh(); let _ = window.draw(cx); });
    let shell = host.read_with(cx, |host, _| host.shell.clone());
    (dir, shell, cx)
}

fn press(cx: &mut VisualTestContext, x: f32, y: f32) {
    cx.simulate_event(MouseDownEvent {
        position: point(px(x), px(y)),
        button: MouseButton::Left,
        click_count: 1,
        ..Default::default()
    });
}

fn drag(cx: &mut VisualTestContext, x: f32, y: f32) {
    cx.simulate_event(MouseMoveEvent {
        position: point(px(x), px(y)),
        pressed_button: Some(MouseButton::Left),
        ..Default::default()
    });
}

#[gpui::test]
fn titlebar_diagnostics_leaving_strip_misses_native_handoff(cx: &mut TestAppContext) {
    let (_dir, shell, cx) = setup(cx, false, false);
    press(cx, 400.0, 2.0);
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move));
    drag(cx, 400.0, -10.0);
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move),
        "native handoff would reset the flag; first upward event missed it");
    eprintln!("TRAJECTORY down=(400,2), held_move=(400,-10): armed=true, native handoff not reached");
    cx.simulate_event(MouseUpEvent {
        position: point(px(400.0), px(-10.0)),
        button: MouseButton::Left,
        ..Default::default()
    });
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move),
        "release outside also fails to clear the titlebar arm");
    eprintln!("TRAJECTORY release=(400,-10): titlebar remains armed");
}

// TestWindow::start_window_move deliberately panics with 'not implemented'.
// These two tests use that boundary as evidence that the real Shell handler
// reached native handoff. They do NOT claim to execute AppKit's drag loop.
#[gpui::test]
#[should_panic(expected = "not implemented")]
fn titlebar_diagnostics_inside_move_reaches_native_boundary(cx: &mut TestAppContext) {
    let (_dir, shell, cx) = setup(cx, false, false);
    press(cx, 400.0, 18.0);
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move));
    eprintln!("TRAJECTORY down=(400,18), held_move=(400,16): native boundary expected");
    drag(cx, 400.0, 16.0);
}

#[gpui::test]
#[should_panic(expected = "not implemented")]
fn titlebar_diagnostics_reentry_reaches_native_boundary(cx: &mut TestAppContext) {
    let (_dir, shell, cx) = setup(cx, false, false);
    press(cx, 400.0, 2.0);
    drag(cx, 400.0, -10.0);
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move));
    eprintln!("TRAJECTORY down=(400,2), held_move=(400,-10), held_move=(400,8): native boundary on reentry expected");
    drag(cx, 400.0, 8.0);
}

fn assert_selection_leak(cx: &mut TestAppContext, occlude: bool) {
    let _guard = crate::markdown::selection::test_state_lock();
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(TEXT_KEY);
    let (_dir, shell, cx) = setup(cx, true, occlude);
    let bounds = crate::markdown::render::selection_test_bounds(TEXT_KEY);
    let position = point(bounds.left() + px(12.0), bounds.top() + px(8.0));
    assert!(position.y >= px(0.0) && position.y < px(Theme::TITLEBAR_HEIGHT),
        "synthetic line must lie underneath the header: {bounds:?}");
    press(cx, position.x.into(), position.y.into());
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move),
        "the real titlebar handler must claim the same down");
    assert!(crate::markdown::selection::is_dragging(),
        "the same click also starts selection in faded-out text");
    eprintln!("TRAJECTORY header down={position:?}: window_drag_armed=true, text_selection_dragging=true, occlude={occlude}");
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(TEXT_KEY);
}

#[gpui::test]
fn titlebar_diagnostics_same_press_arms_window_and_selects_hidden_text(cx: &mut TestAppContext) {
    assert_selection_leak(cx, false);
}

#[gpui::test]
fn titlebar_diagnostics_occlusion_alone_does_not_stop_global_selection(cx: &mut TestAppContext) {
    assert_selection_leak(cx, true);
}

#[gpui::test]
fn titlebar_diagnostics_consuming_owned_press_prevents_selection_leak(cx: &mut TestAppContext) {
    let _guard = crate::markdown::selection::test_state_lock();
    crate::markdown::selection::end_active_drag();
    crate::markdown::selection::clear_if_owner(TEXT_KEY);
    let (_dir, shell, cx) = setup_with_policy(cx, true, false, true, false);
    let bounds = crate::markdown::render::selection_test_bounds(TEXT_KEY);
    let position = point(bounds.left() + px(12.0), bounds.top() + px(8.0));
    press(cx, position.x.into(), position.y.into());
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move));
    assert!(!crate::markdown::selection::is_dragging(),
        "consuming the header-owned down prevents the exact selection leak");
    eprintln!("COUNTERFACTUAL consumed header down={position:?}: window_drag_armed=true, text_selection_dragging=false");
}

#[gpui::test]
#[should_panic(expected = "not implemented")]
fn titlebar_diagnostics_window_scope_handoff_survives_pointer_exit(cx: &mut TestAppContext) {
    let (_dir, shell, cx) = setup_with_policy(cx, false, false, false, true);
    press(cx, 400.0, 2.0);
    assert!(shell.read_with(cx, |shell, _| shell.titlebar_should_move));
    eprintln!("COUNTERFACTUAL window-scoped tracking: down=(400,2), held_move=(400,-10): native boundary expected without reentry");
    drag(cx, 400.0, -10.0);
}
