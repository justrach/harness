#!/usr/bin/env bash
# Synthetic test of Apple's documented immediate-return / omitted-MouseUp case.
# No native application, OS input synthesis, or personal Harness data is used.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
root="$(git -C "$here" rev-parse --show-toplevel)"
work="$(mktemp -d "$here/native-return.XXXXXX")"
mkdir "$work/source"
git -C "$root" archive v0.2.163 | tar -x -C "$work/source"
for file in titlebar_diagnostics.rs titlebar_regressions.rs titlebar_safety.rs titlebar_native_return.rs; do
    cp "$here/$file" "$work/source/crates/ui/src/shell/"
done
cp "$here/native_drag_probe.rs" "$work/source/crates/ui/src/transcript/"
python3 - "$work/source" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
p = root / 'crates/ui/src/shell/titlebar_tests.rs'
s = p.read_text()
assert s.count('use super::*;\n') == 1
p.write_text(s.replace('use super::*;\n', 'use super::*;\n\n#[path = "titlebar_diagnostics.rs"]\nmod titlebar_diagnostics;\n', 1))
p = root / 'crates/ui/src/shell/titlebar_diagnostics.rs'
p.write_text(p.read_text() + '\n#[path = "titlebar_native_return.rs"]\nmod native_return;\n')
p = root / 'crates/ui/src/transcript.rs'
s = p.read_text()
anchor = 'use std::cell::{Cell, RefCell};'
assert s.count(anchor) == 1
p.write_text(s.replace(anchor, '#[cfg(test)]\n#[path = "transcript/native_drag_probe.rs"]\nmod native_drag_probe;\n\n' + anchor, 1))
p = root / 'vendor/zui/crates/gpui/src/platform/test/window.rs'
s = p.read_text()
old = '    fn start_window_move(&self) {\n        unimplemented!()\n    }'
new = '''    fn start_window_move(&self) {
        // Diagnostic only: model documented immediate return, never call OS UI.
        if std::env::var_os("HARNESS_DIAGNOSTIC_NATIVE_RETURN").is_some() {
            return;
        }
        unimplemented!()
    }'''
assert s.count(old) == 1
p.write_text(s.replace(old, new, 1))
PY
export CARGO_TARGET_DIR="$work/target"
export HARNESS_DIAGNOSTIC_NATIVE_RETURN=1
run_test() {
    "$root/scripts/heavy-build.sh" cargo test \
        --manifest-path "$work/source/Cargo.toml" -p harness-ui --lib titlebar_native_return_ \
        -j 4 --config profile.dev.debug=0 --config profile.test.debug=0 \
        -- --nocapture --test-threads=1
}
set +e
run_test > "$work/baseline.log" 2>&1
status=$?
set -e
cat "$work/baseline.log"
if [[ "$status" != 101 ]] || ! grep -Fq 'header-owned native drag left transcript selection and auto-scroll active after handoff' "$work/baseline.log"; then
    printf 'Expected lifecycle failure was not reproduced; inspect setup/build output.\n' >&2
    exit 1
fi
patch -d "$work/source" -p 1 < "$here/handler-candidate.patch"
run_test
printf '\nSynthetic source and results retained at: %s\n' "$work"
